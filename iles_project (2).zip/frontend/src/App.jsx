
import { useState } from "react";

export default function App() {
  const [logs, setLogs] = useState([]);
  const [activity, setActivity] = useState("");

  const addLog = () => {
    setLogs([...logs, activity]);
    setActivity("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>ILES (Simplified)</h2>

      <input
        value={activity}
        onChange={(e) => setActivity(e.target.value)}
        placeholder="Enter activity"
      />
      <button onClick={addLog}>Add Log</button>

      <ul>
        {logs.map((l, i) => (
          <li key={i}>{l}</li>
        ))}
      </ul>
    </div>
  );
}
