
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import InternshipLogViewSet, LoginView

router = DefaultRouter()
router.register("logs", InternshipLogViewSet)

urlpatterns = [
    path("login/", LoginView.as_view()),
    path("", include(router.urls)),
]
