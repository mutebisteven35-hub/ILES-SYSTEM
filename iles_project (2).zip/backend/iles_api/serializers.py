
from rest_framework import serializers
from .models import InternshipLog

class InternshipLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = InternshipLog
        fields = "__all__"
