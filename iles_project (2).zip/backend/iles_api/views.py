
from rest_framework import viewsets
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from django.contrib.auth import authenticate
from .models import InternshipLog
from .serializers import InternshipLogSerializer

class LoginView(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        user = authenticate(username=request.data["username"], password=request.data["password"])
        if not user:
            return Response({"error": "Invalid credentials"}, status=400)

        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            "token": token.key,
            "user_id": user.id,
            "username": user.username,
        })

class InternshipLogViewSet(viewsets.ModelViewSet):
    queryset = InternshipLog.objects.all()
    serializer_class = InternshipLogSerializer

    def perform_create(self, serializer):
        serializer.save(student=self.request.user)
